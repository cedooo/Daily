/*
Navicat MySQL Data Transfer
Source Host     : 10.81.4.193:3306
Source Database : dmsn_998
Target Host     : 10.81.4.193:3306
Target Database : dmsn_998
Date: 2015-12-10 16:26:47
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for tmdatangintegr
-- ----------------------------
DROP TABLE IF EXISTS `tmdatangintegr`;
CREATE TABLE `tmdatangintegr` (
  `SN` varchar(128) NOT NULL,
  `fTitle` varchar(128) NOT NULL,
  `psn` varchar(128) NOT NULL DEFAULT '0',
  `fOrder` decimal(3,0) DEFAULT '998',
  `icon` varchar(24) DEFAULT NULL,
  `fExternalId` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`psn`,`SN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tmdatangintegr
-- ----------------------------
INSERT INTO `tmdatangintegr` VALUES ('node01', '计划营销部', 'node', '2', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node02', '工程管理部', 'node', '3', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node03', '办公厅', 'node', '5', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node04', '资本运营与产权管理部', 'node', '4', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node05', '安全生产部', 'node', '1', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node06', '监察部', 'node', '6', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node08', '工会工作部', 'node', '7', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node09', '政工部', 'node', '9', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node10', '科技信息部', 'node', '10', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node11', '人力资源部', 'node', '8', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node07', '煤炭产业部', 'node', '998', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node12', '财务部', 'node', '998', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node13', '核电部', 'node', '998', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node14', '物资管理部', 'node', '998', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node15', '集团本部_监察局', 'node', '998', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node16', '办公厅', 'node', '998', '', null);
INSERT INTO `tmdatangintegr` VALUES ('node17', '停用', 'node', '998', '', null);
